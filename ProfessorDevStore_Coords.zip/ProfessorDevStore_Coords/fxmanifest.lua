fx_version 'cerulean'
game 'gta5'

author 'Saad / ProfessorDev'
description 'Professor Coords Panel'
version '1.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/app.js',
    'ui/style.css'
}

client_script 'client.lua'

/*
ProfessorDiv Store — by Saad alagele - سعد العجيلي | Discord: 1pd

تحذير:
يُمنع منعًا باتًا فك الحماية أو تعديل التشفير أو إعادة نشر/بيع السكربت دون إذن خطي.
أي انتهاك يُعد خيانة للأمانة وأكلًا للمال بالباطل.

{ وَلَا تَأْكُلُوا أَمْوَالَكُم بَيْنَكُم بِالْبَاطِلِ } (البقرة: 188)
*/
